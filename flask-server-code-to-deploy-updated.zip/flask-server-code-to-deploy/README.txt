Our Application is currently deployed at the following link (on EC2): 
http://34.230.40.205/ 

Our Submission's structure: 

"Final Report.pdf" : contains our report 

"CS 787 - Group Project Presentation.pdf" : contains our presentation (presented on 11/16/2022) 

"CS 787 Project Citations.pdf" : lists a description of sources we referenced throughout our project 

"Final Project Demo-HD1080p.mov": demonstrates use of our application (run locally ) with two different use cases 

"flask-server-code-to-deploy.zip": contains our codebase (relevant individual files are listed below): 
- main.py: includes our server code 
- packingFunctions.py: includes code to run optimizer, calculate annuity investment amount, generate a pareto optimal front, and package system/model input and output
- modelcode.py: includes implementations of our 2 models (used to generate optimal asset allocations and contribution amounts): singleAccountMod() and combiningAccountsMod() 
- personWillBeOKCode.py: includes our diagnosis code implementation 
- our frontend code files: index.html, script.js, .png/.img files, and .css files 

