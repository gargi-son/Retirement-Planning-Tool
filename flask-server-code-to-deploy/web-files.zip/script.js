var turn_on = document.getElementById("turn_on");
var box = document.querySelector(".box");
var field5 = document.getElementById("field5_option");
var add = document.getElementById("add");
var form = document.getElementById("form");
var count = 0;
var options = field5.options;
var optionsLength = Array.from(options).length - 1;
console.log(optionsLength);

turn_on.addEventListener("click", function () {
  box.style.display = "block";
});

field5.addEventListener("change", function () {
  selectedValue = field5.value;
  console.log(optionsLength);
  if (selectedValue === "all" || count === optionsLength) {
    add.style.display = "none";
  } else {
    add.style.display = "block";
  }
});
document.getElementById('outputForm').style.display ='none';
add.addEventListener("click", function () {
  var newField = `<h6><u><em>Other Account</h6></em></u><br><label for="option" class="col-sm-2">Option</label>
    <div class="col-sm-10">
  <select class="form-select" name="field5_option" required>
    <option value="Trad IRA">Trad IRA</option>
    <option value="Roth IRA">Roth IRA</option>
    <option value="Trad 401k">Trad 401k</option>
    <option value="Roth 401k">Roth 401k</option>
    <option value="HSA">HSA</option>
    <option value="Brokerages">Brokerages</option>
  </select>
    </div>
  
  <label for="field5" class="col-sm-2 mt-3 col-form-label">What would be your total yearly investment contribution?</label>
  <div class="col-sm-9 mt-3">
  <input type="number" name="total_yearly_investment_contribution" class="form-control" required/>
  </div>
  <label for="field5" class="col-sm-2 mt-3 col-form-label">What is your current balance in your investment account?</label>
  <div class="col-sm-9 mt-3">
  <input type="number" name="current_balance_investment_accounts" class="form-control" required/>
  </div>

  <label for="field5" class="col-sm-2 mt-3 col-form-label">What would be the rate of return of your investment?</label>
  <div class="col-sm-9 mt-3">
  <input type="number" name="rate_of_return_all_investments" min="0"
  step="0.01" max="1"class="form-control" required/>
  </div>
  <button class="col-sm-1 remove btn btn-outline-danger">X</button>
  <h2 class="h6 mt-3 mb-4"><u><em>Please select your ETF and mutual funds:</em></u></h2>	

  <label for="field5" class="col-sm-2 mt-3 col-form-label">US Stocks
  </label>
  <div class="col-sm-9 mt-3 form-field-inside">
    <select class="form-select" name="usChoice" id="usChoice" required>
      <option value="VOO">VOO</option>
      <option value="VTI">VTI</option>
      <option value="DFAC">DFAC</option>
      <option value="IVV">IVV</option>
      <option value="VUG">VUG</option>
      <option value="SPY">SPY</option>
      <option value="QQQ">QQQ</option>
      <option value="VTV">VTV</option>
    </select>
    <span class="error">This data is required</span>
  </div>

  <label for="field5" class="col-sm-2 mt-3 col-form-label">International Stocks
  </label>
  <div class="col-sm-9 mt-3 form-field-inside">
    <select class="form-select" name="intrnlChoice" id="intrnlChoice" required>
      <option value="VXUS">VXUS</option>
      <option value="SPDW">SPDW</option>
      <option value="VWO">VWO</option>
      <option value="IXUS">IXUS</option>
    </select>
    <span class="error">This data is required</span>
  </div>
  <label for="field5" class="col-sm-2 mt-3 col-form-label">Bonds
  </label>
  <div class="col-sm-9 mt-3 form-field-inside">
    <select class="form-select" name="bondChoice" id="bondChoice" required>
      <option value="BND">BND</option>
      <option value="AGG">AGG</option>
    </select>
    <span class="error">This data is required</span>
  </div>`;
  var newDiv = document.createElement("div");
  newDiv.classList.add("row");
  newDiv.classList.add("mt-4");
  newDiv.innerHTML = newField;
  field5.parentElement.parentElement.appendChild(newDiv);
  count++;
  if (count == optionsLength) {
    add.style.display = "none";
  }
});

document.addEventListener("click", function (e) {
  if (e.target && e.target.classList.contains("remove")) {
    e.target.parentElement.remove();
    count--;
    if (count < optionsLength) {
      add.style.display = "block";
    }
  }
});


form.addEventListener("submit", function (e) {
  e.preventDefault();

  /*var fields = document.querySelectorAll("input[type=text]");
  console.log(fields)
  var fieldsArray = Array.from(fields);*/

  var age_error = document.querySelectorAll(".age_error");
  var retire_age_error = document.querySelectorAll(".retire_age_error");

  var current_age = document.getElementById('field2').value;
  var current_age_prop = document.getElementById('field2');
  var retire_age_prop = document.getElementById('field6');
  console.log("current_age",current_age);
  var retirement_age = document.getElementById('field6').value;
  console.log("retirement_age",retirement_age);
  var age_flag=1;
  var retire_age_flag=1;


  if(current_age_prop && current_age_prop.value){
    if(current_age>0){
      if(current_age < retirement_age){
        age_flag=0;
        age_error[0].style.display="none";
        //console.log("no age error");
      }
      else{
        age_flag=1;
        age_error[0].style.display="block";
        //console.log("age error");
      }
    }
    else{
      age_flag=1;
      age_error[0].style.display="block";
      //console.log("age error");
    }
  }
  

   if(retire_age_prop && retire_age_prop.value){
    console.log("ret")
    if(retirement_age>0){
      if(current_age < retirement_age){
        retire_age_flag=0;
        retire_age_error[0].style.display="none";
        //console.log("no age error");
      }
      else{
        retire_age_flag=1;
        retire_age_error[0].style.display="block";
        //console.log("age error");
      }
    }
    else{
      retire_age_flag=1;
      retire_age_error[0].style.display="block";
     // console.log("age error");
    }
  }


  var current_spending=document.getElementById('field3').value;
  console.log("current_spending",current_spending);
  var current_income=document.getElementById('field1').value;
  console.log("current_income",current_income);
  var taxes_payment=document.getElementById('field4').value;
  console.log("taxes_payment",taxes_payment);
  var spent_constraint_flag=1;
  spent_error=document.querySelectorAll(".spent_error");

  var sum=parseInt(current_spending)+parseInt(taxes_payment);
  console.log("sum",sum);
  if(current_income>sum){
    spent_constraint_flag=0;
    spent_error[0].style.display="none";
  }
  else{
    spent_constraint_flag=1;
    spent_error[0].style.display="block";
  }



  /*var filteredArray = fieldsArray.filter(function (field) {
    return field.id !== "field14" && field.id !== "field15" && field.id!=="field16" && field.id!=="field17";
  });

  var error = document.querySelectorAll(".error");
  var errorCount = 0;
  for (var i = 0; i < filteredArray.length; i++) {
    if (filteredArray[i].value === "") {
      error[i].style.display = "block";
      errorCount++;
    } else {
      if (error[i]) {
        error[i].style.display = "none";
      }
    }
  }*/
  //   if all fields are filled, send data to API
  //if (errorCount === 0 && age_flag===0 && retire_age_flag===0) {
  if (age_flag===0 && retire_age_flag===0 && spent_constraint_flag===0) {
    sendData();
  }
});
// send data to API
async function sendData() {
  // source used to access form elements using .name from html form: https://javascript.info/form-elements
  var form = document.getElementById("form");
  var data = new FormData(form);
  var obj = {};
  for (var [key, value] of data.entries()) {
    obj[key] = value;
  }
  delete obj.field5_option;
  delete obj.total_yearly_investment_contribution;
  delete obj.current_balance_investment_accounts;
  delete obj.rate_of_return_all_investments;
  delete obj.usChoice;
  delete obj.intrnlChoice;
  delete obj.bondChoice;

  var total_yearly_investment_contribution = document.querySelectorAll("input[name=total_yearly_investment_contribution]");
  var field5_sub1Array = Array.from(total_yearly_investment_contribution);
  var current_balance_investment_accounts = document.querySelectorAll("input[name=current_balance_investment_accounts]");
  var field5_sub2Array = Array.from(current_balance_investment_accounts);
  var rate_of_return_all_investments = document.querySelectorAll("input[name=rate_of_return_all_investments]");
  var field5_sub3Array = Array.from(rate_of_return_all_investments);

  var field5_option = document.querySelectorAll("select[name=field5_option]");
  var field5_optionArray = Array.from(field5_option);

  var usChoice = document.querySelectorAll("select[name=usChoice]");
  var field5_sub4Array = Array.from(usChoice);

  var intrnlChoice = document.querySelectorAll("select[name=intrnlChoice]");
  var field5_sub5Array = Array.from(intrnlChoice);

  var bondChoice = document.querySelectorAll("select[name=bondChoice]");
  var field5_sub6Array = Array.from(bondChoice);

  var field5Array = [];
  for (var i = 0; i < field5_optionArray.length; i++) {
    var field5Obj = {};
    field5Obj["type"] = field5_optionArray[i].value;
    field5Obj["total_yearly_investment_contribution"] = field5_sub1Array[i].value;
    field5Obj["current_balance_investment_accounts"] = field5_sub2Array[i].value;
    field5Obj["rate_of_return_all_investments"] = field5_sub3Array[i].value;

    field5Obj["usChoice"] = field5_sub4Array[i].value;
    field5Obj["intrnlChoice"] = field5_sub5Array[i].value;
    field5Obj["bondChoice"] = field5_sub6Array[i].value;

    field5Array.push(field5Obj);
  }
  obj["accounts"] = field5Array;

  console.log(obj);
  // send data to API
   // source used to construct GET and POST requests according to fetch() function syntax: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
  // const response=await fetch("http://127.0.0.1:5000/getrecs", {
  //   method: "POST",
  //   headers: {
  //     "Content-Type": "application/json"
  //   },
    
  //   mode:'cors',
  //   body: JSON.stringify(obj)
  // });

  // console.log(response);
  // if (response.ok) {

  //   const result = await response.json();
  //   console.log(result);
  //   document.getElementById('shravani').style.display ='none';

  //   document.getElementById('shilpa').style.display ='block';
  //   show(result);
  // }

  var systemOutput = {};
  errormsg = "Server Error: Can't get initial recommendations from server."
  systemOutput = await fetchDataFromServer("https://cs787-proj-app.herokuapp.com/getInitRecs", obj, systemOutput, errormsg);

  console.log("SystemOutput:", systemOutput);
  if ((systemOutput !== {})) 
  {
        if (systemOutput.rec1feasible === true) 
        {
            // call /getOptimizedMetric to get minY, maxY, minX, maxX (4 times call)
            var urlOptXY = "https://cs787-proj-app.herokuapp.com/getOptimizedMetric"
            var optInput = {};
            optInput["sysInput"] = obj;
            var axes = ["X", "Y"]
            var minmaxArr = ["min", "max"]
            var optXandYs = {};
            var val = null;
            var containsNull = false;
            var errormsg = "Server Error: cannot get values for "
            for (var i = 0; i < axes.length; i++) {
                for (var j = 0; j < minmaxArr.length; j++) 
                {
                    strBoth = minmaxArr[j] + axes[i]
                    errormsg += strBoth + " "
                    optInput["orderMetric"] = axes[i]
                    optInput["minOrMaxStr"] = minmaxArr[j]
                    val = await fetchDataFromServer(urlOptXY, optInput, val, errormsg)
                    if (val === null) {
                    containsNull = true;
                    }
                    optXandYs[strBoth] = val
                    console.log("got " + strBoth + ":", val)
                    val = null
                }
            }
            if (containsNull === false) 
            {
                // get the values for rec1 options:

                // extract min and max values for axes
                minXval = optXandYs["minX"]
                maxXval = optXandYs["maxX"]
                minYval = optXandYs["minY"]
                maxYval = optXandYs["maxY"]
                console.log("minXval: ", minXval)
                console.log("maxXval: ", maxXval)
                console.log("minYval: ", minYval)
                console.log("maxYval: ", maxYval)

                // get 3 points (calling api 3 times):
                var rec1Input = {};
                rec1Input["sysInput"] = obj
                var rec1OutputParams = {};
                rec1OutputParams["optionCoords"] = [];
                var optionVals = {};
                optionVals["options"] = [];
                rec1OutputParams["optionVals"] = optionVals;
                rec1Input["rec1OutputParams"] = rec1OutputParams;
                rec1Input["minXVal"] = minXval;
                rec1Input["maxXVal"] = maxXval;
                rec1Input["minYVal"] = minYval;
                rec1Input["maxYVal"] = maxYval;

                var numPoints = 3
                var urlRec1Point = "https://cs787-proj-app.herokuapp.com/getOneRec1Option"
                var errormsg3 = "Server Error: cannot get points:  "
                for (var i = 0; i < numPoints; i++) {
                    rec1Input["nextPoint"] = i + 1
                    // reference link : https://www.w3schools.com/jsref/jsref_string.asp
                    // to get syntax to convert integer to a string via String() method and use this method below
                    errormsg3 += "\n"  + String(i + 1) +  " of " + String(numPoints) + " points\n"
                    rec1Input["totalNumPoints"] = numPoints
                    rec1Input["rec1OutputParams"] = await fetchDataFromServer(urlRec1Point, rec1Input, rec1OutputParams, errormsg3)
                }
                // todo: check if error occurred
                systemOutput.Recommendation1_BeforeRet.values = rec1Input["rec1OutputParams"]["optionVals"]

            }
            else 
            {
            console.log("error with getting min and max vals for axes")
            }
        }
        else {
        console.log("after checking rec1feasible = false, returning systemoutput")
        }
    }
    else {
    console.log("after checking initial api, cannot reach server")
    }

    // NEEd: send this systemOutput to Shilpa's output.html
    console.log("systemoutput after rec1check:", systemOutput)
    document.getElementById('inputForm').style.display ='none';
    document.getElementById('outputForm').style.display ='block';
    show(systemOutput);
    return systemOutput;
    // calls: hides index.html form, runs output.js function (add Shilpa's logic here in the function)

}

async function fetchDataFromServer(url, postBody, outputVar, errormsg) {
  // send data to API
   // source used to construct GET and POST requests according to fetch() function syntax: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
   // https://cs787-proj-app.herokuapp.com/
   // http://127.0.0.1:5000/
   //"https://cs787-proj-app.herokuapp.com/getrecs"
  return await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },

    mode:'cors',
    body: JSON.stringify(postBody)
  })
    .then((response) => response.json())
    .then((initData) => {
      //console.log(initData.Recommendation1_BeforeRet)
      //location.href = "https://www.google.com/";
      outputVar = initData
      // console.log("Success:", initData);
      return outputVar
    })
    .catch((error) => {
      errormsg += "Please refresh the page. "
      alert(errormsg)
    console.error('Error:', error);
  });
  //return outputVar;

}

//outputForm script  
$(document).ready(function(){
	$("#modalButton1").click(function(){
	  $("#Modal1").modal();
	});
});
  
$(document).ready(function(){
	$("#modalButton2").click(function(){
	  $("#Modal2").modal();
	});
});

$(document).ready(function(){
	$("#modalButton3").click(function(){
	  $("#Modal3").modal();
	});
});

$(document).ready(function(){
	$("#modalButton4").click(function(){
	  $("#Modal4").modal();
	});
});

function show(data) {
	console.log("data is...")
	console.log(data)

	personOKmsg1.innerHTML = data.personIsOk.msgToDisplay.firstLine;
	personOKmsg2.innerHTML = data.personIsOk.msgToDisplay.secondLine;
	personOKmsg3.innerHTML = data.personIsOk.msgToDisplay.thirdLine;
	personOKmsg4.innerHTML = data.personIsOk.msgToDisplay.fourthLine;

	rec1Possibility = data.rec1feasible;
	console.log(rec1Possibility);

	if (rec1Possibility == true){

	var paretoValues = data.Recommendation1_BeforeRet.values;

	const plotData = []; //['X', 'minY', 'Y', 'Y', 'maxY'];
	for (var i in paretoValues){
		if (i != "options"){
			plotData.push([paretoValues[i]["xcoord"], paretoValues[i]["minY"], paretoValues[i]["ycoord"], paretoValues[i]["ycoord"], paretoValues[i]["maxY"]]);
		}
	} //end of for-loop 

	//choose options message
	var candleStickMsg = data.Recommendation1_BeforeRet.msgToDisplay
	chooseMsg.innerHTML = candleStickMsg;

  //annuities message
	annMsg1.innerHTML = data.Recommendation2_AnnuityPrincipal.msgToDisplay.firstLine;
	annMsg2.innerHTML = data.Recommendation2_AnnuityPrincipal.msgToDisplay.secondLine;
	annMsg3.innerHTML = data.Recommendation2_AnnuityPrincipal.msgToDisplay.thirdLine;
	var AnnuitiesVal = parseFloat(data.Recommendation2_AnnuityPrincipal.values).toFixed(2);
	annCost.innerHTML = "$" + AnnuitiesVal;

  //annuities message - Modal 4
	annMsg14.innerHTML = data.Recommendation2_AnnuityPrincipal.msgToDisplay.firstLine;
	annMsg24.innerHTML = data.Recommendation2_AnnuityPrincipal.msgToDisplay.secondLine;
	annMsg34.innerHTML = data.Recommendation2_AnnuityPrincipal.msgToDisplay.thirdLine;
	var AnnuitiesVal4 = parseFloat(data.Recommendation2_AnnuityPrincipal.values).toFixed(2);
	annCost4.innerHTML = "$" + AnnuitiesVal4;

	google.charts.load('current', { 'packages': ['corechart', 'table', 'gauge'] } );
  google.charts.setOnLoadCallback(drawChart);

	function drawChart() {
		var figure = google.visualization.arrayToDataTable(plotData, true);

		var options = {
		  legend:'none',
		  candlestick: {
			risingColor: {stroke: '#4CAF50'}, //green
      		fallingColor: {stroke: '#F44336'} //red
		  },
		  //colors: ['magenta'] for changing the color of the stick
		  explorer: {
           // axis: 'horizontal',
            keepInBounds: true,
            maxZoomIn: 4.0
          },
		  hAxis: {
			  title: 'cumulative expected return (for all inputted accounts)'
		  },
		  vAxis:{
			  title: ' total account balance by retirement'
		  }
		};
	
		var chart = new google.visualization.CandlestickChart(document.getElementById('chart_div'));
		chart.draw(figure, options);

		// Every time the table fires the "select" event, it should call your selectHandler() function.
		google.visualization.events.addListener(chart, 'select', selectHandler);

		function selectHandler(e) {
  			//alert('A chart point was selected');
			var userSelection = chart.getSelection(); //shows which option the user selected on the graph

			var optionSelected = ("Option" + ((userSelection[0].row) + 1));  //adding '1' beacuse the options are starting with 0
			console.log(optionSelected)
			
			targetOptionJSON = paretoValues[optionSelected] //JSON of selected option
			console.log(targetOptionJSON)

			/* Granular processing */
			var yearlyInvestmentContribution = 0;
			var costIncurred = 0;
			var subAccountNames = [];
			var graph_x_axis = [];
			var dataToplotArr = [];

			subAccounts = targetOptionJSON.rec.sub_account_outputs;
			allAccountsBal = targetOptionJSON.rec.total_balance_from_all_investments_at_end_of_year_range;

			//for line plotting:
			startAge = targetOptionJSON.rec.user_information.year_range_running_model_on.start_age;
			endAge = targetOptionJSON.rec.user_information.year_range_running_model_on.end_age;

			console.log(startAge)
			console.log(endAge)

			//for pie plotting:
			var bondChoice = 0;
			var intrnlChoice = 0;
			var usChoice = 0;
			const accTable = [];
			
			for (const acc of subAccounts){
				yearlyInvestmentContribution += acc.total_yearly_investment_contributions_to_account;
				costIncurred += acc.total_cost_incurred_on_account_by_end_of_range;
				
				//for line plotting
				subAccountNames.push(acc.account_type);
				dataToplotArr.push(acc.total_account_balance_each_year);


				//for pie plotting
				var accType = acc.account_type
				var totaccBal = acc.total_account_balance_at_end_of_range
				for (var i in acc["account_asset_info"])
				{
					var ticker = acc["account_asset_info"][i]["ticker"]
					var contriPer = acc["account_asset_info"][i]["weight"]
					
					var indiAccWgt = contriPer * totaccBal;

					if (i == "bondChoice"){
						var bondChoice = bondChoice + (indiAccWgt/allAccountsBal);
						accTable.push({"AccCategory": i, "Ticker": ticker, "Account": accType, "Individual": (indiAccWgt/allAccountsBal)*100});
					} else if (i == "intrnlChoice"){
						var intrnlChoice = intrnlChoice + (indiAccWgt/allAccountsBal);
						accTable.push({"AccCategory": i, "Ticker": ticker, "Account": accType, "Individual": (indiAccWgt/allAccountsBal)*100});
					} else if (i == "usChoice"){
						var usChoice = usChoice + (indiAccWgt/allAccountsBal);
						accTable.push({"AccCategory": i, "Ticker": ticker, "Account": accType, "Individual": (indiAccWgt/allAccountsBal)*100});
					} else {}
				}
			} //end of for loop
			
			//finalized data for individual contribution
			console.log("Individual Contribution");
			console.log(accTable);

			//finalized data for pie chart
			console.log("Combined Contribution");
			console.log("Bonds");
			console.log(bondChoice*100);
			console.log("International");
			console.log(intrnlChoice*100);
			console.log("US");
			console.log(usChoice*100);

			yearlyInvestmentContribution = Number(yearlyInvestmentContribution.toFixed(2));
			costIncurred =  Number(costIncurred.toFixed(2));
			
			//xcoord for line chart
			for (var age = startAge;  age < endAge; age++){
				graph_x_axis.push(age);
			}

			document.querySelector("#yr-contrib").innerText = yearlyInvestmentContribution;
			document.querySelector("#cost-contrib").innerText = costIncurred;

			//Line Chart - https://stackoverflow.com/questions/71805869/chart-js-using-for-loop
			var colorList = ['orange', 'blue', 'brown', 'green', 'violet', 'black', 'red'];
			const ctx = document.getElementById('myChart').getContext('2d');
			const data0 = {
					labels: graph_x_axis,
					datasets: graph_x_axis.map((ds, i) => ({
						label: subAccountNames[i],
						data: dataToplotArr[i],
						borderColor: colorList[i],
						borderWidth: 1
					  })),
            options: {
              plugins: {
                legend: {
                  labels: {
                    //https://stackoverflow.com/questions/69825359/remove-undefined-label-in-the-upper-part-of-a-chart
                    filter: (legendItem, data) => (typeof legendItem.text !== 'undefined')
                  }
                }
              }
            }
          } //data0 end
			const config = {type: 'line', data: data0,};
			const myChart = new Chart(ctx, config);
					
			//Pie Chart
			const ctx1 = document.getElementById('myPieChart').getContext('2d');
			const data1 = {
					labels: ["Bonds", "US Stocks", "International Stocks"],
					datasets: [{
							label: 'Asset Allocation',
							data: [(bondChoice*100), (usChoice*100), (intrnlChoice*100)],
							backgroundColor: ['rgb(255, 99, 132)','rgb(54, 162, 235)','rgb(255, 205, 86)'],
							hoverOffset: 4
					}]
			};
			const config1 = {type: 'pie', data: data1,};
			const myPieChart = new Chart(ctx1, config1);
			//end of pie chart

			//data collection for individual contributions
			var displayData1 = [];
			var displayData2 = [];
			var displayData3 = [];
			var individualContributions = [];
			for (var i in accTable) {
				if ( (accTable[i]["AccCategory"]) == "bondChoice") {
					displayData1.push({"Account": accTable[i]["Account"], "Contribution": accTable[i]["Individual"]})
				}
				if ( (accTable[i]["AccCategory"]) == "usChoice") {
					displayData2.push({"Account": accTable[i]["Account"], "Contribution": accTable[i]["Individual"]})
				}
				if ( (accTable[i]["AccCategory"]) == "intrnlChoice") {
					displayData3.push({"Account": accTable[i]["Account"], "Contribution": accTable[i]["Individual"]})
				}	
			}
			individualContributions.push({"Bonds":displayData1, "US Stocks":displayData2, "International Stocks":displayData3});
			//console.log(individualContributions);

			//table for individual contributions
			let placeholder = document.querySelector("#indiOutput");
			let out = "";
			for (var x in individualContributions[0]){
				//console.log(x);
				for (var y in individualContributions[0][x]){
					var mergeRows = Object.keys(individualContributions[0][x]).length;
					out += `
					<tr>
						<td>${x}</td>
						<td>${individualContributions[0][x][y]["Account"]}</td>
						<td>${individualContributions[0][x][y]["Contribution"]}</td>
					</tr>
				`;
				}
			}
			//document.querySelector("#merge").setAttribute("colspan", 2);
			placeholder.innerHTML = out;
			console.log(mergeRows) //computed for future use

      $('#showInput').toggle();
			$('#showOutput').toggle("slide"); //displays the pie and line charts
		} // click event function
	}
} //rec1feasibility = true loop ends
else{
	$('#showInput').toggle();
	$('#rec1msgAnnuity').toggle();
	$('#rec2msgAnnuity').toggle();
	var Msg = data.Recommendation1_BeforeRet.msgToDisplay;
	console.log(Msg);
	rec1Msg.innerHTML = Msg;

	var Annutiesmsg0 = data.Recommendation2_AnnuityPrincipal.msgToDisplay;
	var Annutiesmsg = (Annutiesmsg0["firstLine"] +  " " + Annutiesmsg0["secondLine"] + " " + Annutiesmsg0["thirdLine"]);
	//var AnnuitiesVal = parseFloat(data.Recommendation2_AnnuityPrincipal.values).toFixed(2);
	document.getElementById('popAnnuity').setAttribute('data-bs-content', Annutiesmsg); //https://stackoverflow.com/questions/33217791/change-data-content-in-a-bootstrap-popover
}
} //end of show function

function getData(){

myHeaders = new Headers();

fetch('https://cs787-proj-app.herokuapp.com/',{
  method: 'GET',headers: myHeaders,mode: 'cors'
})
  .then((response) => response.json())
  .then((data) => console.log(data));
}
